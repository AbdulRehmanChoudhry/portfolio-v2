const menuBtn = document.getElementById("menuBtn");
const mobileMenu = document.getElementById("mobileMenu");

if (menuBtn && mobileMenu) {
  menuBtn.addEventListener("click", () => {
    const isOpen = mobileMenu.classList.toggle("show");
    menuBtn.setAttribute("aria-expanded", String(isOpen));
  });

  document.querySelectorAll("#mobileMenu a").forEach((link) => {
    link.addEventListener("click", () => {
      mobileMenu.classList.remove("show");
      menuBtn.setAttribute("aria-expanded", "false");
    });
  });
}

// ---------------- INTRO SPLASH ----------------
(function initSplash() {
  const splash = document.getElementById("splash");
  const splashLogo = document.getElementById("splashLogo");
  const navLogo = document.getElementById("navLogo");
  const body = document.body;

  if (!splash || !splashLogo || !navLogo) return;

  const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  if (prefersReducedMotion) {
    splash.classList.add("splash-done");
    return;
  }

  body.classList.add("splash-active");

  // Safety net: never let the splash block the page for more than 6s
  const hardFallback = window.setTimeout(() => {
    splash.classList.add("splash-done");
    body.classList.remove("splash-active");
  }, 6000);

  const finishSplash = () => {
    window.clearTimeout(hardFallback);
    splash.classList.add("splash-done");
    body.classList.remove("splash-active");
  };

  const waitForImage = (img) =>
    img.complete && img.naturalWidth
      ? Promise.resolve()
      : new Promise((resolve) => {
          img.addEventListener("load", resolve, { once: true });
          img.addEventListener("error", resolve, { once: true });
        });

  Promise.all([waitForImage(splashLogo), waitForImage(navLogo)]).then(() => {
    // 1) Logo pulls up into view, centered on a black screen
    requestAnimationFrame(() => {
      splashLogo.classList.add("splash-in");
    });

    // 2) Hold for 2 seconds, then hand off to the nav position
    window.setTimeout(() => {
      const from = splashLogo.getBoundingClientRect();
      const to = navLogo.getBoundingClientRect();

      const scale = to.width / from.width;
      const deltaX = (to.left + to.width / 2) - (from.left + from.width / 2);
      const deltaY = (to.top + to.height / 2) - (from.top + from.height / 2);

      splashLogo.classList.add("splash-out");
      splashLogo.style.transform = `translate(${deltaX}px, ${deltaY}px) scale(${scale})`;
      splash.classList.add("splash-hide");

      // 3) Once the hand-off finishes, remove the splash and unlock the page
      window.setTimeout(finishSplash, 900);
    }, 2000);
  });
})();
const revealTargets = document.querySelectorAll(".reveal");
const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

if (revealTargets.length) {
  if (prefersReducedMotion || !("IntersectionObserver" in window)) {
    revealTargets.forEach((el) => el.classList.add("in-view"));
  } else {
    const revealObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("in-view");
            revealObserver.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.15, rootMargin: "0px 0px -60px 0px" }
    );

    revealTargets.forEach((el) => revealObserver.observe(el));
  }
}
